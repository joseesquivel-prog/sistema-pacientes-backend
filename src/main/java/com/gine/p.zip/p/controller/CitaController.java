package com.gine.p.controller;

public class CitaController {

}
