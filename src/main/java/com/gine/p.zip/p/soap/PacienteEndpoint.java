package com.gine.p.soap;

public class PacienteEndpoint {

}
